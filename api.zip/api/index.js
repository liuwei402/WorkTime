
(function(win){
	// 创建axios实例
	const day = axios.create({
	    baseURL: 'http://10.8.200.157:12345/Platform'
    });
    
	day.interceptors.request.use(function (config) {  
	    
	    return config;
	    }, function (error) {
	    
	    return Promise.reject(error);
	});
	
	function get(path,params){
	    return day.get(path,{
	        
	        params
	    })
	}
	
	function post(path,data={},config={}){
	    return day.post(path,data,config)
	}

	function currentday(day,date="false"){
		let now=new Date()
		if(date=="false")now.setDate(day)
		else{
			now.setMonth(day);
			now.setDate(date)
		}
		return now.getFullYear()+"-"+(now.getMonth()*1+1)+"-"+now.getDate()
	}

	async function getData(path,key1){
		let key2="";
		let start=0;
		let end=0;
		let now=new Date()
		let date=now.getDate()
		let day=now.getDay()
		switch (key1) {
			case "yesdatetime":
				start=currentday(date-1)
				break;
			case "curmonday":
				key2="cursunday";
				start=currentday(date-day+1);
				end=currentday(date-day+7)
				break;
			case "lastmonday":
				key2="lastsunday";
				start=currentday(date-day+1-7);
				end=currentday(date-day+7-7)
				break;
			case "monthStartDate":
				key2="monthEndDate";
				start=currentday(1);
				end=currentday(2,0)
				break;
			case "lastmonthStartDate":
				key2="lastmonthEndDate"
				start=currentday(0,1);
				end=currentday(1,0)
				break;	
			case "startdate":
				key2="stopdate"
				start=currentday(-1,1);
				end=currentday(0,0)
				break;
			default:
				break;
		}
		
		key2?data={
			[key1]:start,
			[key2]:end
		}:data={
			[key1]:start,
		}
		return await post(`${path}?${key1}=${start}${key2?'&'+key2+"="+end:''}`)
	}
	win.day={
		post,
		get,
		getData,
        axios
	}
})(window)



