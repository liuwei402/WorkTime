
// $(async function (){
(async function (){
    let header=await $.ajax("./html/headpart.html")
    let main=await $.ajax("./html/mainpart.html")
    let ipt=await $.ajax("./html/iptpart.html")
    let btn=await $.ajax("./html/btnpart.html")
    let out=await $.ajax("./html/outputpart.html")
    let day=await $.ajax("./html/daypart.html")

    const Shade={
        template:"<section class='shade'><div :class='anime'><p>{{info}}</p><span @click='sure' @mousedown='mousedown' @mouseup='mouseup'>确定</span></div></section>",
        data(){
			return {
				target:null,
			}
		},
		methods: {
            sure(){
                this.$emit("sure")
            },
			mouseup(){
			    $(this.target).removeClass("active") 
			},
			mousedown(e){
			    e=e || window.event;
			    let target=e.target || e.srcElememt;
			    this.target=target
			    $(target).addClass("active")
			    
			},
        },
        props:{
            info:{
                type:String,
                default:""
            },
            anime:{
                type:String,
                default:"showclass"
            }
        },
    }
    const Datepicker={
        template:day,
        data(){
            return {
                value: '',
                value1: '',
                url:"http://10.8.200.157:12345/Platform",
                pickerOptions: {
                    shortcuts: [{
                        text: '最近一周',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '最近一个月',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '最近三个月',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
                            picker.$emit('pick', [start, end]);
                        }
                    }],
                    disabledDate(time) {
                        
                        return time.getTime() > Date.now();
                        // return time.getTime() > Date.now()
                    }
                },
                options: [],
                  
            }
        },
        methods: {
            mouseup(e){
                
                e=e || window.event;
                let target=e.target || e.srcElememt;           
                $(target).removeClass("active")
                
            },
            mousedown(e){
                e=e || window.event;
                let target=e.target || e.srcElememt;
                $(target).addClass("active")
                
            },
            async load(){
                if(this.value==""){
                    alert("请选择组别")
                }else if(this.value1==""){
                    alert("请选择导出起始日期和截至日期")
                }else{
                    let {data}=await window.day.post(`/derive?startdate=${this.value1[0]}&stopdate=${this.value1[1]}&dept=${this.value}`)
                    window.open(this.url+data) 
                }
            },
			
        },
		async mounted(){
			let {data}=await axios.post("http://10.8.200.157:12345/Platform/AcquireDept")
			this.options=data.map(ele=>{return {value:ele.deptname,label:ele.deptname,id:ele.id} })
		}
    }
    
    const Iptpart={
        template:ipt,
        props:{
            user:{
                type:String,
                default:"menber"
            }
        },
        data(){
            return {
                value:`${new Date().getFullYear()}-${new Date().getMonth()+1}-${new Date().getDate()}`,
                time:"",
                contain:"",
                target:null,
                pickerOptions: {
                    disabledDate(time) {
                        let curDate = (new Date()).getTime();
                        let three = 2 * 24 * 3600 * 1000;
                        let threeMonths = curDate - three;
                        return time.getTime() > Date.now() || time.getTime() < threeMonths;;
                    }
                },
            }
        },
        methods: {
            mouseup(){
                $(this.target).removeClass("active").removeClass("act")
                
            },
            mousedown(e){
                e=e || window.event;
                let target=e.target || e.srcElememt;
                if(target.tagName=="I"){
                    target=target.parentNode
                }
                this.target=target
                target.innerText=="提交"?$(target).addClass("active"):$(target).addClass("act")
                
            },
            async edit(){ 
				if(this.value=="" || !this.value){
				    this.$emit("error","请选择日期")
					return false
				}
                let {data}=await axios.post(`http://10.8.200.157:12345/Platform/ChangeWorkTime?CurDate=${this.value}&account=${this.getAccount()}`)
					
                if(data==""){
					this.$emit("error","没有您所查询的内容")
					return false
				}
				this.time=data[0].worktime;
				this.contain=data[0].content;
                         
               
            },
            remove(e){
                this.time="",
                this.contain=""
            },
            async submit(){
                if(this.value =="" || !/\d+-\d+-\d+/.test(this.value)){
                    this.$emit("error","请选择日期")
                }else if(this.time==""){
					this.$emit("error","请输入工时")
				}else if(this.time>24 || this.time<0 ){
                    this.$emit("error","工时需小于24，大于0")
                }else if(this.contain==""){
                    this.$emit("error","请输入工作内容")
                }else{
					
					console.log(this.contain);
					var wortContent = this.contain.replace(new RegExp('\n',"g"),"$");//处理换行问题
					console.log(wortContent);
					
                    let {data}=await axios.post(`http://10.8.200.157:12345/Platform/insert?nameworktime=${this.time}&namecontent=${encodeURI(wortContent)}&namedate=${this.value}&account=${this.getAccount()}`)
                    
                    this.$emit("submitSuccess",data)
					this.time="",//
					this.contain=""
                }
            },	
			clearTime(){
				this.time=this.time.replace(/(?=\D)[^\.]/g,"");
				console.log(this.time.length)
				this.time.length>4?this.time=this.time.slice(0,4):"";
			},
            getAccount(){
                let str=window.location.href.indexOf("account"),account;
                str==-1?account=null:(window.location.href.slice(str+8).indexOf("&")==-1?account=window.location.href.slice(str+8):account=window.location.href.slice(str+8).split("&")[0]);
                return window.atob(account)
            }
        },
        created() {            
            document.addEventListener("mouseup",this.mouseup)
        },
    }
    const Btnpart={
        template:btn,
        data(){
            return {
                value:"",
				target:null,
                url:"http://10.8.200.157:12345/Platform"
            }
        },
        methods: {
            async lastMonth(){
                let {data}=await window.day.getData("/lastmonth","lastmonthStartDate");
                window.open(this.url+data)
            },
            async thisMonth(){
                let {data}=await window.day.getData("/curmonth","monthStartDate");
                window.open(this.url+data)
            },
            async lastWeek(){
                let {data}=await window.day.getData("/lastweek","lastmonday");
                window.open(this.url+data)
            },
            async thisWeek(){
                let {data}=await window.day.getData("/curweek","curmonday");
                window.open(this.url+data)
            },
            async yesterday(){
                let {data}=await window.day.getData("/yeterday","yesdatetime");
                window.open(this.url+data)
            },
			mouseup(){
			    $(this.target).removeClass("cur")
			    
			},
			mousedown(e){
				
			    e=e || window.event;
			    let target=e.target || e.srcElememt;
			    this.target=target
			    $(target).addClass("cur")
			    
			},
        },
    }
    const Oputpart={
        template:out,
        data(){
            return {
                value:""
            }
        },
        
        components:{
            Datepicker,
        }
    }
    const Headpart={
        template:header
    }
    const Mainpart={
        template:main,
        props:{
            user:{
                type:String,
                default:"menber"
            }
        },
        data(){
            return {
                info:"",
                anime:"showclass",
                show:false
            }
        },
        methods: {
            submitSuccess(info){
                this.anime="showclass"
                this.info=info
                this.show=true
            },
            error(info){
                this.anime="showclass"
                this.info=info
                this.show=true
            },
            sure(){
                this.anime="hideclass"
                setTimeout(()=>{
                    this.show=false

                },390)
            }
        },
        components:{
            // Editpart,
            Iptpart,
            Btnpart,
            Oputpart,
            Shade
        
        }
    }
    

    new Vue({
        el:"#app",
        data:{
            msg:"hello"
        },
        components:{
            Headpart,
            Datepicker,
            Mainpart,
      
        }
    }) 

})()
// })